package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"strconv"
)

// Definición de las estructuras Profesor y Estudiante
type Profesor struct {
	IdProfesor int
	CUI        string
	Nombre     string
	Curso      string
}

type Estudiante struct {
	IdEstudiante int
	CUI          string
	Nombre       string
	Carnet       string
}

// Funciones para escribir en el archivo binario
func writeProfesor(profesor Profesor, file *os.File) {
	jsonData, err := json.Marshal(profesor)
	if err != nil {
		fmt.Println("Error al serializar el profesor:", err)
		return
	}
	file.Write(append(jsonData, '\n'))
}

func writeEstudiante(estudiante Estudiante, file *os.File) {
	jsonData, err := json.Marshal(estudiante)
	if err != nil {
		fmt.Println("Error al serializar el estudiante:", err)
		return
	}
	file.Write(append(jsonData, '\n'))
}

// Funciones para leer del archivo binario
func readProfesores(file *os.File) []Profesor {
	var profesores []Profesor
	file.Seek(0, 0)
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		var profesor Profesor
		err := json.Unmarshal(scanner.Bytes(), &profesor)
		if err == nil && profesor.IdProfesor != 0 {
			profesores = append(profesores, profesor)
		}
	}
	return profesores
}

func readEstudiantes(file *os.File) []Estudiante {
	var estudiantes []Estudiante
	file.Seek(0, 0)
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		var estudiante Estudiante
		err := json.Unmarshal(scanner.Bytes(), &estudiante)
		if err == nil && estudiante.IdEstudiante != 0 {
			estudiantes = append(estudiantes, estudiante)
		}
	}
	return estudiantes
}

// Funciones para manejar el menú y la interacción con el usuario
func main() {
	file, err := os.OpenFile("registros.bin", os.O_RDWR|os.O_CREATE, 0666)
	if err != nil {
		fmt.Println("Error al abrir el archivo:", err)
		return
	}
	defer file.Close()

	scanner := bufio.NewScanner(os.Stdin)
	for {
		fmt.Println("Menú Principal:")
		fmt.Println("1. Registro de Profesor")
		fmt.Println("2. Registro de Estudiante")
		fmt.Println("3. Ver Registros")
		fmt.Println("4. Salir")
		fmt.Print("Seleccione una opción: ")

		scanner.Scan()
		opcion := scanner.Text()

		switch opcion {
		case "1":
			registrarProfesor(file, scanner)
		case "2":
			registrarEstudiante(file, scanner)
		case "3":
			verRegistros(file)
		case "4":
			fmt.Println("Saliendo...")
			return
		default:
			fmt.Println("Opción no válida")
		}
	}
}

// Funciones para registrar Profesor y Estudiante
func registrarProfesor(file *os.File, scanner *bufio.Scanner) {
	fmt.Print("Ingrese el ID del Profesor: ")
	scanner.Scan()
	id, _ := strconv.Atoi(scanner.Text())

	fmt.Print("Ingrese el CUI: ")
	scanner.Scan()
	cui := scanner.Text()

	fmt.Print("Ingrese el Nombre: ")
	scanner.Scan()
	nombre := scanner.Text()

	fmt.Print("Ingrese el Curso: ")
	scanner.Scan()
	curso := scanner.Text()

	profesor := Profesor{
		IdProfesor: id,
		CUI:        cui,
		Nombre:     nombre,
		Curso:      curso,
	}

	writeProfesor(profesor, file)
	fmt.Println("Profesor registrado correctamente")
}

func registrarEstudiante(file *os.File, scanner *bufio.Scanner) {
	fmt.Print("Ingrese el ID del Estudiante: ")
	scanner.Scan()
	id, _ := strconv.Atoi(scanner.Text())

	fmt.Print("Ingrese el CUI: ")
	scanner.Scan()
	cui := scanner.Text()

	fmt.Print("Ingrese el Nombre: ")
	scanner.Scan()
	nombre := scanner.Text()

	fmt.Print("Ingrese el Carnet: ")
	scanner.Scan()
	carnet := scanner.Text()

	estudiante := Estudiante{
		IdEstudiante: id,
		CUI:          cui,
		Nombre:       nombre,
		Carnet:       carnet,
	}

	writeEstudiante(estudiante, file)
	fmt.Println("Estudiante registrado correctamente")
}

// Función para ver registros
func verRegistros(file *os.File) {
	profesores := readProfesores(file)
	estudiantes := readEstudiantes(file)

	fmt.Println("Profesores Registrados:")
	for _, profesor := range profesores {
		fmt.Printf("ID: %d, CUI: %s, Nombre: %s, Curso: %s\n",
			profesor.IdProfesor, profesor.CUI, profesor.Nombre, profesor.Curso)
	}

	fmt.Println("Estudiantes Registrados:")
	for _, estudiante := range estudiantes {
		fmt.Printf("ID: %d, CUI: %s, Nombre: %s, Carnet: %s\n",
			estudiante.IdEstudiante, estudiante.CUI, estudiante.Nombre, estudiante.Carnet)
	}
}
